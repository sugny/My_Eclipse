package com.javaPgm.test;

public class ArmStrong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 153 = 1*1*1 + 5*5*5 + 3*3*3 = 1 + 125 + 27 = 153

		Integer input = 1634,result=input;
		String str = input.toString();
		int l = str.length();
		int mod = 0;
		double sum = 0;
		while (input > 0) {
			mod = input % 10;
			sum = sum + Math.pow(mod, l);
			input = input / 10;
		}
		long round = Math.round(sum);
		System.out.println(Math.round(sum));
		if(result==round) {
			System.out.println(round + " is ArmStrong Number");
		}
		else
			System.out.println(round + " Not is ArmStrong Number");
	}

}
