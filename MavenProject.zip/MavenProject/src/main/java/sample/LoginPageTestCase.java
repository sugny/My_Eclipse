package sample;

import org.testng.annotations.Test;

public class LoginPageTestCase {
	
	@Test
	public void Login() {
		
		LoginPage lp = new LoginPage();
		lp.loginCredentials();
	}

}
