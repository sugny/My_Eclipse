package javaproblems;

import java.util.Scanner;

public class StringPalindrome {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a word : ");
		String input = sc.nextLine();
		sc.close();
		StringPalindrome.isPalindrome(input);
	}

	public static void isPalindrome(String input) {

		int length = input.length();
		System.out.println(length);
		String revString = "";
		for (int i = (length - 1); i >= 0; i--) {

			revString = revString + input.charAt(i);
		}
		if (revString.equalsIgnoreCase(input)) {
			System.out.println(revString + " is a palindrome");
		} else {
			System.out.println(revString + " Not a palindrome");
		}
	}

}
