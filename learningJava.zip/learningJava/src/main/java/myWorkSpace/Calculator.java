package myWorkSpace;

public class Calculator {

	public int add(int a, int b) {
		return a + b;
	}
	
	public float add(float a, float b){
		return a + b;
	}
	
	
	
}
