package com.javaPgm.test;

public class WordCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "   he given string is e   ?";
		str = str.trim().replaceAll("\\s+", " ");
		String[] split = str.split(" ");
		int length = split.length;
		System.out.println("Length of the String : " + length);

		int count = 1;
		if (!str.isEmpty()) {
			for (int i = 0; i < str.length(); i++) {
				if (str.charAt(i) == ' ') {
					count++;
				}
			}
			System.out.println("Length of the String : " + count);
		} else
			System.out.println("The given string is empty");
	}

}
