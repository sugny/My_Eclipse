package myWorkSpace;

import java.util.Scanner;

public class primeNumber {

	public static void main(String[] args) {
		
		Scanner myObj = new Scanner(System.in);
		System.out.print("Enter a number : ");
		
		int number = myObj.nextInt();
		System.out.println(number);
		for(int i=2; i<number; i++){
			if(number/i !=0){
				System.out.println("is prime");
			}
			else {
				System.out.println("not prime");
			}
			
		}
	}

}
