package week7.day2.string;

public class ReverseString {

	public static void main(String[] args) {
		
		// Here is the input
				String test = "feeling good";
				
		// Convert the String to character array
				char[] charArray = test.toCharArray();
				int length = test.length();
				System.out.println(length);
				
		//Traverse through each character (using loop in reverse direction)
				for(int i=length-1;i>=0;i--) {
					System.out.print(charArray[i]);
				}				
			}
	}
