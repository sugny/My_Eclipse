package com.javaPgm.test;

public class ArraySort {

	public static void main(String[] args) {

		int[] arr = { 21, 3, 2, 5, 19, 5, 8};
		int l=arr.length;
		int temp =0;
		for(int i=0;i<l;i++) {
			for(int j=i+1;j<l;j++) {
				if(arr[i]>arr[j]) {
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
			System.out.println(arr[i]);
		}
		System.out.println("Second Largest "+ arr[l-2]);
	}
}
