package myWorkSpace;

import java.time.format.TextStyle;

public class EntryPoint {

	static int i=0;
	
	public static void main(String[] args) {
	
		EntryPoint t =new EntryPoint();
		print();
		
		
		
	}

	public static void print() {
		// TODO Auto-generated method stub
		System.out.println(i);
	}
}
