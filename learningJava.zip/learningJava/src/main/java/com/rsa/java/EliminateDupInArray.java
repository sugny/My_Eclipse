package com.rsa.java;

public class EliminateDupInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] a = { 2, 2, 3, 5, 1, 2, 5, 10,10,10,10};
		int l = a.length;
		sorting(a, l);
	
		int[] b = new int[l];
		int i=0;
		for (int k = 0; k < l-1; k++) {
			if (a[k] != a[k + 1])
				b[i++]=a[k];
				//System.out.println(b[c]);
		}
		b[i++] = a[l-1];  
		for(int j=0;j<i;j++) {
			System.out.println(b[j]);
		}
	}

	public static int[] sorting(int[] a, int l) {
		int temp = 0;
		for (int i = 0; i < l; i++) {
			for (int j = i + 1; j < l; j++) {
				if (a[i] >= a[j]) {
					temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
			//System.out.println(a[i]);
		}
		return a;
	}
}
