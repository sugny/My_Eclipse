package week6.day1.assignment2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.github.sukgu.Shadow;

public class CreateIncident {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://dev137617.service-now.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.findElement(By.xpath("//input[@id='user_name']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@id='user_password']")).sendKeys("Password!123");
		driver.findElement(By.xpath("//button[@id='sysverb_login']")).click();
		
		Shadow shadow = new Shadow(driver);
		shadow.setImplicitWait(30);
		WebElement elementAll = shadow.findElementByXPath("//div[text()='All']");
		elementAll.click();
		
		Actions actions = new Actions(driver); 
		
		WebElement elementFilter = shadow.findElementByXPath("//input[@id='filter']");
		actions.moveToElement(elementFilter);
		actions.click().perform();
		elementFilter.sendKeys("Incident");
		Thread.sleep(1000);
		elementFilter.sendKeys(Keys.ENTER);
		Thread.sleep(1000);
		
		WebElement elementFrame = shadow.findElementByXPath("//iframe[@id='gsft_main']");
		driver.switchTo().frame(elementFrame);
		driver.findElement(By.xpath("//button[@id='sysverb_new']")).click();
		driver.findElement(By.xpath("//input[@id='incident.short_description']")).sendKeys("abc");
		driver.findElement(By.xpath("(//button[text()='Submit'])[2]")).click();
		
		WebElement elementSort = driver.findElement(By.xpath("(//span[@class='sort-icon column_header_icon'])[1]"));
		actions.click(elementSort).perform();
		Thread.sleep(2000);
		String incidentNumber1 = driver.findElement(By.xpath("(//a[@class='linked formlink'])[1]")).getText();
		WebElement elementSearch = driver.findElement(By.xpath("(//input[@placeholder='Search'])[1]"));
		actions.moveToElement(elementSearch);
		elementSearch.sendKeys(incidentNumber1);
		System.out.println(incidentNumber1);
		elementSearch.sendKeys(Keys.ENTER);
		String incidentNumber2 = driver.findElement(By.xpath("//a[@class='linked formlink']")).getText();
		System.out.println(incidentNumber2);
		if(incidentNumber1.equals(incidentNumber2)) {
			System.out.println("New Instance is created");
		}
		else {
			System.out.println("No Instance is created");
		}
	}

}
