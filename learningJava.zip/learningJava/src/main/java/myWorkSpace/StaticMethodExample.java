package myWorkSpace;

public class StaticMethodExample {

	public static int add (int a, int b){
		return a + b;
	}
}
