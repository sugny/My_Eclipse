package com.javaPgm.test;

public class Practice {

	public static void main(String[] args) {
		
		//pseudo code
		//	1
		//	1 2
		//	1 2 3
		//	1 2 3 5
		
		
		int input =4;
		int temp =0;
		for(int i=1;i<=6;i++) {
			int a =0;
			int b=1;
			for(int j=1;j<=i;j++) {
				temp = a+b;
				System.out.print(temp+" ");
				a=b;
				b=temp;
			}
			System.out.println(" ");			
		}		
	}
}
