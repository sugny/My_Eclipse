package week5.marathon2;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.github.sukgu.Shadow;

public class AdministratorCertifications {

	public static void main(String[] args) {
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get(" https://login.salesforce.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		

		WebElement elementUsername = driver.findElement(By.id("username"));
		elementUsername.sendKeys("ramkumar.ramaiah@testleaf.com");
		
		WebElement elementPassword = driver.findElement(By.id("password"));
		elementPassword.sendKeys("Password#123");
		
		WebElement elementLogin = driver.findElement(By.id("Login"));
		elementLogin.click();
		
		
		driver.findElement(By.xpath("//span[text()='Learn More']")).click();
		
		Set<String> windowHandlesSet = driver.getWindowHandles();
		List<String> windowHandlesList = new ArrayList<String>(windowHandlesSet);
		driver.switchTo().window(windowHandlesList.get(2));
		driver.findElement(By.xpath("//button[text()='Confirm']")).click();
		
		Shadow shadow = new Shadow(driver);
		
		
		WebElement elementLearning = shadow.findElementByXPath("//span[text()='Learning']");
		elementLearning.click();
		
		WebElement elementTrailhead = shadow.findElementByXPath("//span[text()='Learning on Trailhead']");
		
		Actions act = new Actions(driver);
		act.moveToElement(elementTrailhead).perform();
		
		shadow.findElementByXPath("//a[text()='Salesforce Certification']").click();
		
		driver.findElement(By.xpath("//a[@href='/en/credentials/administrator']")).click();
		
		String title = driver.getTitle();
		System.out.println("Page Title : "+title);
		System.out.println("--------------------");
		
		List<WebElement> verify = driver.findElements(By.xpath("//div[@class='credentials-card_title']"));
		
		String text = null;
		
		for (WebElement webElement : verify) {
							
				text = webElement.getText();
				/*
				 * all certifications 
					System.out.println(text);
				*/
			if(text.contains("Administrator"))
				System.out.println("Certifications available for Administrator : "+text);
				
		}
		
	}

}
