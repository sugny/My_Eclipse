package com.rsa.java;
public class SwapTheVariable {
	
	public static void main(String[] agrs) {
		
		/*
		 * Scanner sc = new Scanner(System.in);
		 * 
		 * System.out.println("Enter a number"); int input = sc.nextInt();
		 */
		int a = 10;
		int b=20;
		
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("A = "+ a);
		System.out.println("B = "+ b);
		
		
	}

}
