package com.rsa.java;

public class AdjacentDiff {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] a = { 1, 7, 5, 9, 7, 8 };
		int l = a.length;
		int diff = 0;
		int sub =0;
		for (int i = 0; i < l - 1; i++) {

			sub = a[i + 1] - a[i];
			System.out.println(sub);
			if (a[i + 1] - a[i] > diff)
				diff = a[i + 1] - a[i];
		}
		System.out.println(diff);

	}

}
