package week3.day1.breakoutsession;

public class Auto extends Vehicle{
	
	public void handStarter() {
		System.out.println("Auto --> handStarter");
	}

}
