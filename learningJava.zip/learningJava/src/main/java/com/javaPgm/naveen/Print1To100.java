package com.javaPgm.naveen;


public class Print1To100 {
	
	public static void main(String[] args) {
		stringToInteger("1");
		stringToInteger("hi");
		stringToInteger("2");	
	}
	public static void stringToInteger(String a) {
		try {
			int c = Integer.parseInt(a);
			System.out.println(c);
		} catch (Exception e) {
			System.out.println("Invalid inpust : "+a);
			e.printStackTrace();
		}
	}
	 
	
	public static void stringToInt(String a) {
			int c= Integer.parseInt(a);
			System.out.println(c);
		}
}
