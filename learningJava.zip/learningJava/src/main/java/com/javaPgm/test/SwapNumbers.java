package com.javaPgm.test;

public class SwapNumbers {

	public static void main(String[] args) {

		String str = "Saket Saurav        is an Autom ation Engi ne      er";
		char[] charArray = str.toCharArray();
		int l = charArray.length;
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<l;i++) {
			if(charArray[i]!= ' ') {
				sb.append(charArray[i]);
			}
		}
		System.out.println(sb);
	}
}
