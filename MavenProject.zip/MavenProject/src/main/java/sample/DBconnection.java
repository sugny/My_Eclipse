package sample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBconnection {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		String jdbc_driver = "com.mysql.jdbc.Driver";
		String jdbc_url = "jdbc:mysql://localhost:3306/employee";
		
		String username = "localhost";
		String password = "welcome";
		
		Class.forName(jdbc_driver);
		Connection connection = DriverManager.getConnection(jdbc_url,username,password);
		Statement createStatement = connection.createStatement();
		String sql = "SELECT * FROM employee.emp_details";
		ResultSet executeQuery = createStatement.executeQuery(sql);
		
		while(executeQuery.next()) {
			String employeeID = executeQuery.getString("Employee ID");
			System.out.println(employeeID+" "+executeQuery.getString(3));
		}		
	}

}
