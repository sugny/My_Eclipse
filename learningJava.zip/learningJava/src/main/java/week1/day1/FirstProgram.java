package week1.day1;

public class FirstProgram {

	
		
		byte number1 = 12;
		short number2 = 356;
		int number3 = 25675;
		long number4 = 12586822L; 
		float number5 = 123.4585F;
		double number6= 1242.41254875656458;
		char myInitial= 'N';
		boolean coding= true;
		String myName = "Suganya";
		
		
	}


