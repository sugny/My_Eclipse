package hooks;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class runHooks {
	@Before
	public void before(Scenario sc) {
		System.out.println(sc.getSourceTagNames());
		System.out.println(sc.getStatus());
		System.out.println(sc.getLine());
	}
	@After
	public void after(Scenario sc) {
		System.out.println(sc.getStatus());
	}
}
