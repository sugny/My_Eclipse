package com.rsa.java;

public class FibanocciSeries {
	
	public static int a = 0;
	public static int b = 1;
	public static int temp = 0;
	public static int input = 8;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 1 2 3 5 8

	
		System.out.println(a+" ");
		/*
		 *  for (int i = 0; i <input; i++) { temp = a+b; a= b;
		 * b=temp; System.out.print(temp + " "); }
		 */
		
		int j=0;
		while(j<input) {
			
			temp = a+b;
			a= b;  
			b=temp; 
			j++;
			System.out.println(temp);
		}
	}

}
