package com.rsa.java;

public class ReverseAString {

	public static void main(String[] args) {
		
		
		String input = "Malayalam";
		//System.out.println(c);
		//StringBuffer input = new StringBuffer(c);
		//input.reverse();
		System.out.println(input);
		int l = input.length();
		String reverse = "";	
		for(int i=l-1;i>=0;i--) {
			
			reverse = reverse+input.charAt(i);
		}
		System.out.println(reverse);
		
		if(input.equals(reverse)) {
			
			System.out.println("The given word "+ input + " is a Palindrome" );
		}
		else
			System.out.println("The given word is NOT a Palindrome");
		
	}

}
