package sample;

import java.time.Duration;
import java.util.ArrayList;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class JavaSE_Test {

	@Test
	public void Login() {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(options);
		driver.get("https://www.leafground.com/window.xhtml");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

		driver.findElement(By.xpath("//span[text()='Open Multiple']")).click();

		Set<String> windowHandles = driver.getWindowHandles();
		List<String> list = new ArrayList<String>(windowHandles);

		for (String title : list) {
			driver.switchTo().window(title);
			System.out.println(driver.getTitle());
		}
		driver.switchTo().window(list.get(2));
		driver.manage().window().maximize();
		System.out.println(driver.getTitle());
		WebElement eleSearch = driver.findElement(By.xpath("//input[@placeholder='Search']"));
		eleSearch.sendKeys("hello");
		eleSearch.sendKeys(Keys.ENTER);
	}
}