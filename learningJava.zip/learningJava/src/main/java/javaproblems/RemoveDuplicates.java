package javaproblems;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

public class RemoveDuplicates {
	
    
	   
    public static void main (String[] args) {
        
        int[] arr = {1,5,8,4,6,9,10,21,1,5,4,21};
        Arrays.sort(arr);
        List<Integer> list = new ArrayList<Integer>();
        for(int eachValue : arr){
            list.add(eachValue);
        }
        System.out.println(list);
        Collections.sort(list);
        HashSet<Integer> toSet = new HashSet<Integer>(list);
        System.out.println(toSet);
    }
    


}
