package javaproblems;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter an integer value : ");
		int number = sc.nextInt();
		sc.close();
		int result = number;
		result = reverseNumber(result);
		System.out.println(result);
	}

	/*public static int isReversedNumber(int number) {

		int rem = 0, rev = 0;
		while (number > 0) {
			rem = number % 10;
			rev = rev*10 + rem;
			number = number / 10;
		}
		return rev;*/
		
	public static int reverseNumber(int number) {
		
		int rem =0,rev =0;
		for(;number!=0;) {
			rem =number%10;
			rev = rev*10+rem;
			number=number/10;
		}
		return rev;
		
	}

}
