package com.rsa.java;

public class DuplicatesInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 2, 1, 6, 2, 4, 3, 5 };
		int l = arr.length;
		int[] b = new int[l];
		int k=0;
		for (int i = 0; i <l-1; i++) {
				if (arr[i] != arr[i+1]) {
					b[k++] = arr[i];
					//System.out.println(b[k]);
				}	
			}
		b[k++] = arr[l-1];
		for(int i=0;i<l;i++) {
			System.out.println(b[i]);
		}
	}
}
