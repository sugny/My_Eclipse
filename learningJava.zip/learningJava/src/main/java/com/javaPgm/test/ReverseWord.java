package com.javaPgm.test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class ReverseWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<Integer, String> map = new LinkedHashMap<>();
		map.put(431, "Priya");
		map.put(145, "Jaya");
		map.put(256, "Nowfal");
		map.put(109, "Hari");
		map.put(679, "Raji");
		map.put(987, "Danny");
		map.put(431, "Prashanthi");
		int size = map.size();
		System.out.println(map);
		System.out.println(map.get(679));
		
		Set<Integer> set = new HashSet<>();
		
	}

}
