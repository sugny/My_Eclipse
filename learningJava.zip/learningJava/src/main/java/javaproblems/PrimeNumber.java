package javaproblems;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number greater than 1 : ");
		int number = sc.nextInt();
		sc.close();
		PrimeNumber pm = new PrimeNumber();
		pm.isPrime(number);

	}

	public void isPrime(int number) {
		int count = 0;
		for (int i = 2; i < number; i++) {
			if (number % i == 0)
				count = count + 1;
		}
		if (count == 0)
			System.out.println(number + " Prime");
		else
			System.out.println(number + " Not Prime");
	}
}
