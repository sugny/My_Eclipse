package myWorkSpace;

import java.util.ArrayList;
import java.util.List;

public class reverseSentence {

	public static void main(String[] args) {
		
		String statement = "Hello this is God";
		System.out.println(statement);
		
		List<String> sentence = new ArrayList<String>();
		sentence.add("Hello");
		sentence.add("This");
		sentence.add("is");
		sentence.add("God");
		System.out.println(sentence);
		int size = sentence.size();
		
		for (int i=size-1;i>=0;i--) {
			
			System.out.println(sentence.get(i));
			
		}

		
		
	}

}
