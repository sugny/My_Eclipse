package week1.day1;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int fact=1;
		int input =5;
		
		
		for (int i = 1; i <=input; i++) {
			
			
			fact = fact*i;
			//System.out.println(fact + " after ");
		}
		System.out.println("The factorial of 5 is " + fact);
		
	}

}

/*What are my learnings from this code?
	- understood for loop iterations 

*/

