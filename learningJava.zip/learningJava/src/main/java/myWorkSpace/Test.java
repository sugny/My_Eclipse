package myWorkSpace;

public class Test {

	public static void main(String[] args) {
		
		
		Testing t = new Testing();
		t.sample();
		

	}

}

