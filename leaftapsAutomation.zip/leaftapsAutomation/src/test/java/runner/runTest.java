package runner;

import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = { "src/test/java/features/Login.feature" }, 
					glue = { "steps","hooks"}, monochrome = true, publish = true,
							plugin = {"pretty", "html:target/Destination"},
					tags = "@Smoke")
public class runTest extends AbstractTestNGCucumberTests {
	
	@Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }

}
