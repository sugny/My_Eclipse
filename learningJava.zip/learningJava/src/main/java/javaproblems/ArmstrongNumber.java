package javaproblems;

import java.util.Scanner;

public class ArmstrongNumber {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int number = sc.nextInt();
		sc.close();
		ArmstrongNumber an = new ArmstrongNumber();
		an.isArmstrongNumber(number);
		
	}

	public void isArmstrongNumber(int number) {
	
		int rem; 
		int input = number;
		int sum = 0;
		while(number>0) {
			rem = number%10;
			sum = (int) (sum+ Math.pow(rem,3));
			number = number/10;
		}
		System.out.println(sum);
		
		if(input==sum)
			System.out.println("is Armstrong Number");
		else
			System.out.println("Not a Armstrong Number");
	}
}
