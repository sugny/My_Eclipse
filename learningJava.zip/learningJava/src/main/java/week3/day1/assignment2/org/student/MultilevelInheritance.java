package week3.day1.assignment2.org.student;

public class MultilevelInheritance {

	public static void main(String[] args) {
		
		Student student = new Student();
		student.studentName();
		student.studentDept();
		student.studentId();
		
		student.deptName();
		
		student.collegeName();
		student.collegeCode();
		student.collegeRank();
		
	}

}
