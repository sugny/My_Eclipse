package week2.day1;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;
import week7.day2.assignment.IOpropertyFile;

public class AssignmentCreateLead {
	
	//Automation to Create Lead
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		//chrome browser
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(options);
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().window().maximize();
		//driver.close();
		
		driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
		
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		
		driver.findElement(By.className("decorativeSubmit")).click();
		
		driver.findElement(By.linkText("CRM/SFA")).click();
		
		
		  WebElement elementLeads = driver.findElement(By.linkText("Leads"));
		  elementLeads.click();
		  
		  WebElement elementCreateLead =
		  driver.findElement(By.linkText("Create Lead")); elementCreateLead.click();
		  
		  WebElement elementCompanyName =
		  driver.findElement(By.id("createLeadForm_companyName"));
		  elementCompanyName.sendKeys("Amazon");
		  
		  WebElement elementFirstName =
		  driver.findElement(By.xpath("//input[@id='createLeadForm_firstName']"));
		  elementFirstName.sendKeys("jeff");
		  
		  WebElement elementLastName =
		  driver.findElement(By.id("createLeadForm_lastName"));
		  elementLastName.sendKeys("bezos");
		  
		  WebElement elementFirstNameLocal =
		  driver.findElement(By.id("createLeadForm_firstNameLocal"));
		  elementFirstNameLocal.sendKeys("stark");
		  
		  WebElement elementDepartmentName =
		  driver.findElement(By.id("createLeadForm_departmentName"));
		  elementDepartmentName.sendKeys("Executive");
		  
		  WebElement elementDescription =
		  driver.findElement(By.id("createLeadForm_description"));
		  elementDescription.sendKeys("Founder and CEO");
		  
		  WebElement elementEmailAddress =
		  driver.findElement(By.id("createLeadForm_primaryEmail"));
		  elementEmailAddress.sendKeys("abc@gmail.com");
		  
		  WebElement elementSubmit = driver.findElement(By.className("smallSubmit"));
		  elementSubmit.click();
		  
		  String tittle = driver.getTitle();
		  System.out.println("The Tittle of the page is : "+tittle);
		  
		 		
	}

}
