package com.leaftaps.pages;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class DeleteLead extends ProjectSpecificMethods {
	
	@Test
	public void runDeleteLead() throws InterruptedException {
		
		driver.findElement(By.id("username")).sendKeys("democsr");
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		driver.findElement(By.className("decorativeSubmit")).click();
		driver.findElement(By.linkText("CRM/SFA")).click();
		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Find Leads")).click();
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys("98");
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
		String text = driver.findElement(By.xpath("(//a[@class='linktext'])[4]")).getText();
		System.out.println("lead ID : "+text);
		driver.findElement(By.xpath("(//a[@class='linktext'])[4]")).click();
		
	}
}
