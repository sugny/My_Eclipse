package week3.day2.assignment1;

public class MultipleLangauge {
	
	public void python(){
		
		System.out.println("Python");
		
	}

}
