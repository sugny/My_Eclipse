package javaproblems;

public class LuckyInteger {

	public static void main(String[] args) {
		
		 int input[] = {2,2,3,4,4};
		 int length = input.length;
		 int count =0;
		 /*System.out.println(Arrays.asList(2,3,3,3,4,4).stream().
		 collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
		 .entrySet().stream().filter(e -> (long)e.getKey()==e.getValue()).findFirst().get().getKey());
				*/ 
		 for(int i=0;i<length-1;i++){
				 if(input[i]==input[i+1]){
					 count=count+1;
					 System.out.println(input[i]);
				 }
			 }
		}
	}
