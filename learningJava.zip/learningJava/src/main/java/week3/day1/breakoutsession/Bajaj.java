package week3.day1.breakoutsession;

public class Bajaj extends Auto {
	public void electronicMeter() {
		System.out.println("Bajaj --> electronicMeter");
	}

}
