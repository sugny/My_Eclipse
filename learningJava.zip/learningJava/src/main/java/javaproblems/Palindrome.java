package javaproblems;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		
		System.out.println("Please Enter a word : ");
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		int length = input.length();
		String reverseStr = "";
		for(int i=length-1;i>=0;i--) {
			reverseStr = reverseStr + input.charAt(i);
		}
		System.out.println(reverseStr);
		if(reverseStr.equalsIgnoreCase(input)) {
			System.out.println("ok");
		}
		else
			System.out.println("Not ok");
		sc.close();
	}
}
