package sample;


public class LoginPage {
	
	public void loginCredentials() {
		
		String username = "Suganya";
		String password = "abcd";
		System.out.println("Username : "+username);
		System.out.println("Password : "+password);
	}
	
}
