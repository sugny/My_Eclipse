package week3.day1.assignment2.org.department;

import week3.day1.assignment2.org.college.College;

public class Department extends College {
	
	public void deptName() {
		System.out.println("Department ECE");
	}
	

}
