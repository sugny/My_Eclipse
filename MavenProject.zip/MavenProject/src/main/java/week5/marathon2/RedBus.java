package week5.marathon2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RedBus {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.redbus.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		WebElement elementSource = driver.findElement(By.xpath("//input[@id='src']"));
		elementSource.sendKeys("Che");
		driver.findElement(By.xpath("//input[@id='src']/../ul[@class='autoFill homeSearch']/li[2]")).click();
		
		WebElement elementDestination = driver.findElement(By.xpath("//input[@id='dest']"));
		elementDestination.sendKeys("Bang");
		driver.findElement(By.xpath("//input[@id='dest']/../ul[@class='autoFill homeSearch']/li[2]")).click();

		driver.findElement(By.xpath("//input[@id='onward_cal']")).click();
		
		WebElement elementNextday = driver.findElement(By.xpath("//div[@id='rb-calendar_onward_cal']/table/tbody/tr[3]/td[7]"));
		elementNextday.click();
		
		driver.findElement(By.xpath("//button[@id='search_btn']")).click();
		
		String elementBussesFound = driver.findElement(By.xpath("//span[contains(@class,'busFound')]")).getText();
		System.out.println(elementBussesFound);
	}
	

}
