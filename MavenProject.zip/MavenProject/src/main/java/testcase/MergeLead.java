package testcase;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import org.testng.annotations.Test;


public class MergeLead extends ProjectSpecificMethods {
		@Test
		public void mergeLead() throws InterruptedException {
			

			WebElement elementUsername = driver.findElement(By.id("username"));
			elementUsername.sendKeys("Demosalesmanager");
			
			WebElement elementPassword = driver.findElement(By.id("password"));
			elementPassword.sendKeys("crmsfa");
			
			WebElement elementLogin = driver.findElement(By.className("decorativeSubmit"));
			elementLogin.click();
			
			WebElement elementLink = driver.findElement(By.linkText("CRM/SFA"));
			elementLink.click();
			
			driver.findElement(By.linkText("Contacts")).click();
			
			driver.findElement(By.xpath("//a[text()='Merge Contacts']")).click();
			
			driver.findElement(By.xpath("(//img[@alt='Lookup'])[1]")).click();
			
			Set<String> windowHandles1 = driver.getWindowHandles();
			List<String> windowHandlesToList1 = new ArrayList<String>(windowHandles1);
			
			driver.switchTo().window(windowHandlesToList1.get(2));
			
			driver.findElement(By.xpath("(//a[@class='linktext'])[1]")).click();
			
			driver.switchTo().window(windowHandlesToList1.get(1));
					
			driver.findElement(By.xpath("(//img[@alt='Lookup'])[2]")).click();
			
			Set<String> windowHandles2 = driver.getWindowHandles();
			List<String> windowHandlesToList2 = new ArrayList<String>(windowHandles2);
			
			driver.switchTo().window(windowHandlesToList2.get(2));
			
			driver.findElement(By.xpath("(//a[@class='linktext'])[5]")).click();
			
			driver.switchTo().window(windowHandlesToList2.get(1));
			
			driver.findElement(By.xpath("//a[text()='Merge']")).click();
			
			driver.switchTo().alert().accept();
			
			String title = driver.getTitle();
			System.out.println(title);
			
			if(title.contains("View Contact | opentaps CRM"))
				System.out.println("The title is Verified");
			else
				System.out.println("The Title doesnt match");
			
		
	}
}






