package week3.day2.assignment1;

public interface Language {
	
	public void java();
	public void javaScript();
	public void ruby();

	
}
