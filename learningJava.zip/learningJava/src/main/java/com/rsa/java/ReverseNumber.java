package com.rsa.java;

public class ReverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int input = 115634423;
		int mod=0;
		int sum=0;
		while(input>0) {
			mod = input%10;
			sum=mod+sum*10;
			input = input/10;	
		}
		System.out.println(sum);

	}

}
