package javaproblems;

import java.util.Scanner;

public class NumberPalindrome {
	
	public static int sum = 0, rem = 0;
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number : ");
		int input = sc.nextInt();
		sc.close();
		NumberPalindrome np = new NumberPalindrome();
		np.isNumberPalindrome(input);
		if (sum == input)
			System.out.println(sum + " given Number is a palindrome");
		else
			System.out.println(sum + " not a palindrome");

	}

	

	public int isNumberPalindrome(int input) {
		while (input > 0) {
			rem = input % 10;
			sum = sum * 10 + rem;
			input = input / 10;
		}
		return sum;
	}

}
