package steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginSteps {
	
	ChromeDriver driver;
	
	@Given("Open the browser - maximize and set the timeouts")
	public void setUpBrowser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	@And ("load the url {string}")
	public void loadURL(String url) {
		driver.get(url);
	}
	
	@Given ("Enter the username {string}") 
	public void enterUsername(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
	}
	
	@And ("Enter the password {string}")
	public void enterPassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}
	
	@When ("click login button")
	public void clickLoginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}
	
	@But ("verify the Error Message Displayed")
	public void verifyErrorMessage() {
		String message = driver.findElement(By.id("errorDiv")).getText();
		System.out.println(message);
	}
	
	@Then ("verify the Success Message")
	public void verifySuccessMessage() {
		String text = driver.findElement(By.tagName("h2")).getText();
		System.out.println(text);
	}
	

	


}
