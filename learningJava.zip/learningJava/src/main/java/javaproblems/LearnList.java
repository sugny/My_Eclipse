package javaproblems;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

public class LearnList {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(10, 20, 3, 4, 5, 6, 7, 8, 9, 10);
		System.out.println(list);
		int size = list.size();
		for (int i = 0; i < size; i++) {
			if (list.get(i) % 2 != 0)
				System.out.println(list.get(i));
		}
		List<String> name = Arrays.asList("apricot", "apple", "mango", "orange");
		System.out.println(name);
		for (String nameList : name) {
			if (nameList.startsWith("a"))
				System.out.println(nameList);
		}

		String[] initials = { "zzz", "bb", "cc", "zzz" };
		// System.out.println(Arrays.toString(initials));
		List<String> toList = new ArrayList<String>();
		for (String toRemoveDuplicates : initials) {

			toList.add(toRemoveDuplicates);

		}
		System.out.println(toList);
		HashSet<String> toSet = new HashSet<String>();
		toSet.addAll(toList);
		System.out.println(toSet);
		
	}

}
