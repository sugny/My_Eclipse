package javaproblems;

import java.util.Scanner;

public class RemoveSpecialChars {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a sentence with special characters : ");
		String input = sc.nextLine();
		sc.close();
		RemoveSpecialChars rs = new RemoveSpecialChars();
		String removeSplChars = rs.isRemoveSplChars(input);
		System.out.println(removeSplChars);
		RemoveSpecialChars.learnObj();

	}

	public String isRemoveSplChars(String input) {

		String replace = input.replaceAll("[^a-z,A-Z,0-9]", " ");
		return replace;

	}

	public static void learnObj() {
		System.out.println("Hi");
	}
	
}
