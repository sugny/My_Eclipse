package com.leaftaps.pages;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class CreateLead extends ProjectSpecificMethods {

	@BeforeTest
	public void setData() {
		excelFileName = "tc001";
	}

	@Test(dataProvider = "testData")
	public void runCreateLead(String userName, String passWord, String cName, String fname, String lName) {

		driver.findElement(By.id("username")).sendKeys(userName);
		driver.findElement(By.id("password")).sendKeys(passWord);
		driver.findElement(By.className("decorativeSubmit")).click();
		driver.findElement(By.linkText("CRM/SFA")).click();
		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		driver.findElement(By.name("submitButton")).click();
	}

	/*
	 * @DataProvider(name = "testData") public String[][] sendData() {
	 * 
	 * String[][] data = new String[2][5];
	 * 
	 * data[0][0] = "democsr"; data[0][1] = "crmsfa"; data[0][2] = "abc"; data[0][3]
	 * = "haran"; data[0][4] = "hari";
	 * 
	 * data[1][0] = "democsr"; data[1][1] = "crmsfa"; data[1][2] = "xyz"; data[1][3]
	 * = "haran"; data[1][4] = "sai";
	 * 
	 * return data;
	 */
}
