package week7.day2.assignment;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateLead {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		IOpropertyFile pf = new IOpropertyFile();
		// chrome browser
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get(pf.readPropertyFile("url"));
		driver.manage().window().maximize();
		driver.findElement(By.id("username")).sendKeys(pf.readPropertyFile("username"));
		driver.findElement(By.id("password")).sendKeys(pf.readPropertyFile("password"));
		driver.findElement(By.className("decorativeSubmit")).click();
		driver.findElement(By.linkText("CRM/SFA")).click();
		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("qaz");
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("zaq");
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("xsw");
		driver.findElement(By.name("submitButton")).click();
		
		String tittle = driver.getTitle();
		System.out.println("The Tittle of the page is : "+tittle);	
		
		pf.writePropertyFile(tittle);
	}

}
