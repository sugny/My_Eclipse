package week3.day1.assignment3;

public class OverRide {

	public static void main(String[] args) {
		
		AxisBank axisBank = new AxisBank();
		axisBank.deposit();
		axisBank.getDeposit();
		
	}

}
