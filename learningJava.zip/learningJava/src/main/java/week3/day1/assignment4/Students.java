package week3.day1.assignment4;

public class Students {
	
	public void getStudentInfo(int id) {
		System.out.println("ID " +id);
	}
	
	public void getStudentInfo(String id, String name) {
		System.out.println("ID" +id);
		System.out.println("Name " +name);
	}
	
	public void getStudentInfo(int phoneNumber, String emailID) {
		System.out.println("phoneNumber " +phoneNumber);	
		System.out.println("emailID " +emailID);
	}
}
