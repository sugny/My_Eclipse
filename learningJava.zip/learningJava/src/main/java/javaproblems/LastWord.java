package javaproblems;

import java.util.Scanner;

public class LastWord {

	public static void main(String[] args) {
		/*
		 * System.out.println("Please enter the sentence : "); Scanner sc = new
		 * Scanner(System.in); String input = sc.nextLine(); String[] split =
		 * input.split("\\s"); int length = split.length; String lastWord =
		 * split[length-1]; int lastWordLength = lastWord.length();
		 * System.out.println("The last word is : "+lastWord+ " with length "+
		 * lastWordLength); sc.close();
		 */
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a sentence : ");
		String sentence = sc.nextLine();
		sc.close();
		String[] split = sentence.split(" ");
		int islength = split.length;
		String lastword = split[islength-1];
		int isLastwordLength = lastword.length();
		System.out.println("Length of the last word : "+isLastwordLength);
		System.out.println("Lastword : "+lastword);
	}
}

