package week3.day1.assignment2.org.student;

import week3.day1.assignment2.org.department.Department;

public class Student extends Department {
	
	public void studentName() {
		System.out.println("student Name xyz");
	}
	
	public void studentDept() {
		System.out.println("student Dept ECE");
	}
	
	public void studentId() {
		System.out.println("student ID 123");
	}
	

}
