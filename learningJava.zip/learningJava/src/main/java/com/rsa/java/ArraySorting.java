package com.rsa.java;

public class ArraySorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] a = { 10, 20, 11, 52, 1, 8, 6 };
		int l = a.length;
		int temp = 0;
		for (int i = 0; i < l; i++) {
			for (int j = i + 1; j < l; j++) {
				if (a[i] > a[j]) {   
					temp = a[i];  //20
					a[i] = a[j];  //11
					a[j] = temp;	//20
				}

			}
			System.out.println(a[i]);

		}

	}
}
