package myWorkSpace;

public class Testing {
	
	public void sample() {
		
		System.out.println("Sample is called");
	}
	public Testing() {
		
		System.out.println("Check");
	}

}
