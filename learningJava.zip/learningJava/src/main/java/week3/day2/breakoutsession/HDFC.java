package week3.day2.breakoutsession;

public class HDFC implements RBIinterface {
	
	public void provideCreditCard(boolean provideCreditCard) {
		System.out.println("provide Credit Card");
	}

	public void minimumBalance(int minimumBalance) {
		System.out.println("minimum Balance is 500");
		
	}

	public void provideDebitCard(boolean provideDebitCard) {
		System.out.println("provide Debit Card");
		
	}

}
