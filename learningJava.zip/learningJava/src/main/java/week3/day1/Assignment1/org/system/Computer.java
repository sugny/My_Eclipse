package week3.day1.Assignment1.org.system;

public class Computer {
	
	public void computerModel(){
		System.out.println("computerModel Method");
	}

}
