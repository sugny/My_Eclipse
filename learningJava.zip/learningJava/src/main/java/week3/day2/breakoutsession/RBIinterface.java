package week3.day2.breakoutsession;

public interface RBIinterface {
	
	/** minimumBalance should be 500;
	 * 	provide DebitCard for all the customers with savings account
	
	*/
	public void minimumBalance(int minimumBalance);
	public void provideDebitCard(boolean provideDebitCard);
	
}
