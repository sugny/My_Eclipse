package week4.day1.assignments;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.Assertion;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Windows {

	public static void main(String[] args) throws InterruptedException {

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(options);

		/*
		 * WebDriverManager.chromedriver().setup();
		 *
		 */
		driver.get("https://www.leafground.com/window.xhtml");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		// Click and Confirm new Window Opens
		driver.findElement(By.xpath("//span[text()='Open']")).click();
		
		System.out.println(driver.getTitle());
		
		String parentWindow = driver.getWindowHandle();
		System.out.println(parentWindow);

		Set<String> windowHandlesSet1 = driver.getWindowHandles();
		List<String> windowHandlesList1 = new ArrayList<String>(windowHandlesSet1);
		String child = windowHandlesList1.get(1);
		System.out.println(child);
		driver.switchTo().window(parentWindow);
		
		System.out.println(driver.getTitle());
		
		

		/*
		 * String title = driver.getTitle(); System.out.println("First Child Window : "
		 * + title);
		 */

		//Assert.assertEquals(title, "Dashboard");
		  
		/*
		 * if(title.contains("Dashboard")) System.out.println("New Window is Verified");
		 * else System.out.println("Not Verified");
		 */
		  
		  
		  //Find the number of opened tabs
			/*
			 * driver.switchTo().window(windowHandlesList1.get(1));
			 * driver.findElement(By.xpath("//span[text()='Open Multiple']")).click();
			 * Set<String> windowHandlesSet2 = driver.getWindowHandles(); List<String>
			 * windowHandlesList2 = new ArrayList<String>(windowHandlesSet2);
			 * System.out.println("The number of opened tabs :"+windowHandlesList2.size());
			 * 
			 * //Close all windows except Primary
			 * driver.findElement(By.xpath("//span[text()='Close Windows']")).click();
			 * System.out.println("Parent Window Title :" +driver.getTitle());
			 * 
			 * // getWindowHandle - will always have the parent window String windowHandle =
			 * driver.getWindowHandle();
			 * 
			 * for (String childWindowHandle : driver.getWindowHandles()) {
			 * driver.switchTo().window(childWindowHandle); if
			 * (driver.getTitle().equals("Window")){ // System.out.println("Parent Window");
			 * } else driver.close(); }
			 * 
			 * // Using same list windowHandlesList2.clear(); Set<String> windowHandlesSet3
			 * = driver.getWindowHandles(); windowHandlesList2.addAll(windowHandlesSet3);
			 * driver.switchTo().window(windowHandlesList2.get(0));
			 * 
			 * //Wait for 2 new tabs to open
			 * driver.findElement(By.xpath("//span[text()='Open with delay']")).click();
			 * 
			 * 
			 * // Explicit Wait
			 * 
			 * WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(25));
			 * wait.until(ExpectedConditions.visibilityOfElementLocated(By.
			 * xpath("//span[text()='Open with delay']"))).click();
			 * 
			 */
	}

}
