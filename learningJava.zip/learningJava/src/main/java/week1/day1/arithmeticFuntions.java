package week1.day1;

public class arithmeticFuntions {
	 
	public static void main(String[] args) {
		
	}
	
	public int addThreeNumbers(int num1,int num2,int num3){
			int sumOfThreeNumbers = num1+num2+num3;
			return sumOfThreeNumbers;
	}
	
	public int subTwoNumbers(int num1,int num2){
		int subOfTwoNumbers = num1-num2;
		return subOfTwoNumbers;
}
	
	public float mulThreeNumbers(float num1,float num2,float num3){
		float mulThreeNumbers = num1*num2*num3;
		return mulThreeNumbers;
}
	
	public int divTwoNumbers(int num1,int num2){
		int divTwoNumbers = num1/num2;
		return divTwoNumbers;
	
}
	
}