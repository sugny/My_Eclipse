package week3.day1.breakoutsession;

public class Car extends Vehicle {
	
	public void openSunroof(){
		System.out.println("Car --> openSunroof");
	}


	public void turnOnAC(){
		System.out.println("Car --> turnOnAC");
	}
}
