package util;

public class Utils {

	public static void printArray(char[] arr) {
		for(char c : arr){
			System.out.print(c);
			System.out.print(", ");
		}
		System.out.println();

	}
	
	public static void printArray(int[] arr) {
		for(int c : arr){
			System.out.print(c);
			System.out.print(", ");
		}
		System.out.println();

	}
	
	public static void printArray(String[] arr) {
		for(String c : arr){
			System.out.print(c);
			System.out.print(", ");
		}
		System.out.println();

	}
}
