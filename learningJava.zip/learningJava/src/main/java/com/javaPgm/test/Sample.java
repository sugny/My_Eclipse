
package com.javaPgm.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Sample {

	public static void main(String[] args) {

		// input = 12476222
		// output = 14762222

		List<Integer> list = Arrays.asList(1, 2, 4, 6, 7, 2, 2, 2);
		List<Integer> list1 = new ArrayList<Integer>();
		
		// System.out.println(list.get(5));
	
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		for (int i = 0; i < list.size(); i++) {
			if(map.containsKey(list.get(i))) {
				int count = map.get(list.get(i));
				map.put(list.get(i), count++);
			}
			else
				map.put(list.get(i), 1);
		}
		System.out.println(map);
	}

}
