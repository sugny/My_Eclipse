package sample;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.aventstack.extentreports.MediaEntityBuilder;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LearnScreenShot {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(options);
		// ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		int random = (int) (Math.random() * 100000000);

		System.out.println(random);

		/*
		 * File source = driver.getScreenshotAs(OutputType.FILE);
		 * 
		 * File target = new File("./ss/"+random+".jpg");
		 * 
		 * FileUtils.copyFile(source, target);
		 */

		File source = driver.getScreenshotAs(OutputType.FILE);

		File target = new File("./ss/" + random + ".jpg");

		FileUtils.copyFile(source, target);

		MediaEntityBuilder createScreenCaptureFromBase64String = MediaEntityBuilder
				.createScreenCaptureFromBase64String(source.toString());

		driver.close();

	}

}
