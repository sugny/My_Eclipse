package javaproblems;

import java.util.Scanner;

public class HappyNumber {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter an integer : ");
		int number = sc.nextInt();
		sc.close();
		int result = number;
		
		HappyNumber obj = new HappyNumber();
		obj.test();
		
		while (result != 1 && result != 4) {
			//result = isHappyNumber(result);
		
		}
		if (result == 1) {
			System.out.println("Happy");
		} else {
			System.out.println("not Happy");
		}

	}

	public  int isHappyNumber(int number) {

		int sum = 0, rem = 0;
		while (number > 0) {
			// 123 = 1 2 3
			rem = number % 10;
			sum = sum + (rem * rem);
			number = number / 10;
		}
		test();
		return sum;		

	}
	public  void test() {
		
		System.out.println("New");
	}

}
