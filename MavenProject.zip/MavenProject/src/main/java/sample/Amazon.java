package sample;

import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

@Test
public class Amazon {

	// public static void main(String[] args) throws InterruptedException {

	public void table() {

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(options);

		driver.get("https://erail.in/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
		WebElement eleFrom = driver.findElement(By.id("txtStationFrom"));
		eleFrom.clear();
		eleFrom.sendKeys("ms",Keys.TAB);
		
		WebElement eleTo = driver.findElement(By.id("txtStationTo"));
		eleTo.clear();
		eleTo.sendKeys("mdu",Keys.TAB);
		
		WebElement eleSortOnDate = driver.findElement(By.id("chkSelectDateOnly"));
		eleSortOnDate.click();
		
		List<WebElement> eleTrainList = driver.findElements(By.xpath("//table[@class='DataTable TrainList TrainListHeader stickyTrainListHeader']//tr"));
		int rowSize = eleTrainList.size();
		System.out.println(rowSize);
		List<String> listOfTrains = new ArrayList<String>();
		for(int i=2;i<=rowSize;i++) {
			String trainName = driver.findElement(By.xpath("//div[@id='divTrainsList']/table[1]/tbody/tr["+i+"]/td[2]/a")).getText();
			System.out.println(trainName);
			listOfTrains.add(trainName);
		}
		int trainListWithDuplicates = listOfTrains.size();
		
		Set<String> setTrainNames = new LinkedHashSet<String>(listOfTrains);
		int trainWithoutDuplicates = setTrainNames.size();
		
		if(trainListWithDuplicates==trainWithoutDuplicates) {
			System.out.println("No Duplicates");
		}
		else
			System.out.println("has duplicates");
	}

}
