package features;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = {"src/test/java/features/LoginTest.feature"},
				glue = {"steps", "hooks"},
				tags= "@sanity or @smoke", 
				monochrome = true,
				publish = true)
public class RunTest extends AbstractTestNGCucumberTests{

}
