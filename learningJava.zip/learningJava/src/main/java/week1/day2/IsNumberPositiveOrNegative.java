package week1.day2;

//import java.util.Scanner;

public class IsNumberPositiveOrNegative {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int number = 25;
		
		/* Scanner enterNumber = new Scanner(System.in);
		int Number = enterNumber.nextInt();
		
		System.out.print("Enter the Number ");
				
		*/
		
		if(number > 0)
			System.out.print("The Number is Positive");
			else 
			System.out.print("The Number is Negative");

	}

}
