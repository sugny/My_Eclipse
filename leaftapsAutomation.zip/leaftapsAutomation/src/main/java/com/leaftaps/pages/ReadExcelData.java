 package com.leaftaps.pages;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelData {

	public static String[][] getData(String excelFileName) throws IOException {

		// open book
		XSSFWorkbook book = new XSSFWorkbook("./testData/"+ excelFileName +".xlsx");
		// select sheet
		XSSFSheet sheet = book.getSheetAt(0);
		// find row size
		int rowCount = sheet.getLastRowNum();
		//System.out.println("rowCount " + rowCount);
		// find col size
		XSSFRow header = sheet.getRow(0);
		short colCount = header.getLastCellNum();
		//System.out.println("colCount " + colCount);
		
		String[][] data = new String[rowCount][colCount];
		// iterate to get each cell value
		for (int i = 1; i <= rowCount; i++) {
			XSSFRow row = sheet.getRow(i);
			for (int j = 0; j < colCount; j++) {
				XSSFCell cell = row.getCell(j);
				String value = cell.getStringCellValue();
				data[i-1][j]= value;
			}
			
		}
		book.close();
		return data;
	}

}
