package steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.*;
public class LoginSteps {

	public ChromeDriver driver;

	@Given("Open the chrome browser - maximize and set timeouts")
	public void openBrowser() {
		
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

	@And("Load the application URL {string}")
	public void loadUrl(String url) {
		driver.get(url);
	}

	@And("Enter the Username {string}")
	public void enterUsername(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
	}

	@And("Enter the Password {string}")
	public void enterPassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}

	@When("Login button is clicked")
	public void loginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("Verify the Logged in is sucessful")
	public void verifySucessMessage() {
		String loginMessage = driver.findElement(By.tagName("h2")).getText();
		System.out.println(loginMessage);
	}

	@But("Verify the Logged in is unsucessful")
	public void verifyErrorMessage() {
		String message = driver.findElement(By.id("errorDiv")).getText();
		System.out.println(message);
	}
}
