package week6.day1.assignment2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.github.sukgu.Shadow;

public class UpdateExistingIncident {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://dev137617.service-now.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.findElement(By.xpath("//input[@id='user_name']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@id='user_password']")).sendKeys("Password!123");
		driver.findElement(By.xpath("//button[@id='sysverb_login']")).click();
		
		Shadow shadow = new Shadow(driver);
		shadow.setImplicitWait(30);
		WebElement elementAll = shadow.findElementByXPath("//div[text()='All']");
		elementAll.click();
		
		Actions actions = new Actions(driver); 
		
		WebElement elementFilter = shadow.findElementByXPath("//input[@id='filter']");
		actions.moveToElement(elementFilter);
		actions.click().perform();
		elementFilter.sendKeys("Incident");
		Thread.sleep(1000);
		elementFilter.sendKeys(Keys.ENTER);
		Thread.sleep(1000);
		
		WebElement elementFrame = shadow.findElementByXPath("//iframe[@id='gsft_main']");
		driver.switchTo().frame(elementFrame);
		
		WebElement elementSort = driver.findElement(By.xpath("(//span[@class='sort-icon column_header_icon'])[1]"));
		actions.click(elementSort).perform();
		Thread.sleep(2000);
		
		//Update the incidents with Urgency as High and State as In Progress

		driver.findElement(By.xpath("//tbody[@class='list2_body']/tr[1]/td[3]/a")).click();		
		driver.findElement(By.xpath("(//select[@id='incident.urgency'])/option[1]")).click();
		driver.findElement(By.xpath("//select[@id='incident.state']/option[2]")).click();
		driver.findElement(By.xpath("//button[@id='sysverb_update']")).click();
		Thread.sleep(1000);
		
		//Verify the priority and state 
		driver.findElement(By.xpath("//tbody[@class='list2_body']/tr[1]/td[3]/a")).click();
		Thread.sleep(1000);
		String elementState = driver.findElement(By.xpath("//li[1]/span[text()='Incident state']//following::span[1]/span[1]")).getText();
		System.out.println("State : "+elementState);
		String elementPriority = driver.findElement(By.xpath("(//span[text()='Priority'])[1]/following::span[1]/span[1]")).getText();
		System.out.println("Priority : "+elementPriority);
	}

}
