package week3.day1.breakoutsession;

public class BMW extends Car  {
	
	public void autoPark() {
		System.out.println("BMW --> autoPark");
	}


}
