package com.rsa.java;

public class SumOfArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//addArray();
		multiple();
		arrayInterSection();
	}

	public static void addArray() {
		int[] a = { 1, 2, 3, 4, 5, 10 };
		int l = a.length;
		// System.out.println(l);
		int sum = 0;
		for (int i = 0; i < l; i++) {

			sum = sum + a[i];
		}
		// System.out.println(sum);
	}

	public static void multiple() {

		int a = 5;
		int b = 10;
		int sum = 0;
		for (int i = 1; i <= b; i++) {

			sum = sum + a;
			System.out.println(sum);
		}
		//System.out.println(sum);
	}

	public static void arrayInterSection() {

		int[] a = { 1, 1, 5, 4, 3, 8, 10 };
		int[] b = { 1, 1, 5, 1, 3, 7, 10 };
		int l = a.length;
		// ArrayList<Integer> arrList = new ArrayList<Integer>();
		for (int i = 0; i < l; i++) {

			if (a[i] == b[i]) {
				System.out.println(a[i]);
			} 
		}

	}

}
