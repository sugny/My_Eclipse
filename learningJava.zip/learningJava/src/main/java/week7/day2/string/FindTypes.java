package week7.day2.string;

public class FindTypes {

	public static void main(String[] args) {
		// Here is the input
		String test = "$$ Welcome to 2nd Class of Automation $$ ";

		// Here is what the count you need to find
		int  letter = 0, space = 0, num = 0, specialChar = 0;
		
		char[] charArray = test.toCharArray();
		int length = charArray.length;
		char c = 0;

		for(int i=0;i<length;i++) {
			 c = charArray[i];
			 if(Character.isLetter(c))
				 letter++;
			 else if(Character.isDigit(c))				
				 num++;
			 else if(Character.isSpaceChar(c))				 
				 space++;
			 else			
			 specialChar++;
			}
		 System.out.println("Letter "+ letter);	
		 System.out.println("digit "+ num);
		 System.out.println("Space " +space);
		 System.out.println("specialCharcter " +specialChar);
	}
}

	