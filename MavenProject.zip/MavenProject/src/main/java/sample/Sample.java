package sample;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.Assert;


public class Sample {

	public static void main(String[] args) {
		/*
		 * ChromeOptions options = new ChromeOptions();
		 * options.addArguments("--remote-allow-origins=*"); RemoteWebDriver driver =
		 * new ChromeDriver(options);
		 */

		FirefoxOptions options = new FirefoxOptions();
		options.addArguments("dom.webnotifications.enabled");
		//options.addPreference("dom.webnotifications.enabled", false);

		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.google.com");
		// driver.manage().

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		String actualTitle = driver.getTitle(); 
		WebElement eleSearch = driver.findElement(By.xpath("//textarea[@title='Search']"));
		eleSearch.sendKeys("selenium",Keys.ENTER);
		
		String expectedTitle = driver.getTitle();
		System.out.println(actualTitle+" "+expectedTitle);
		Assert.assertEquals(actualTitle, expectedTitle);
		Assert.assertTrue(true, expectedTitle);
		driver.close();
		

	}

}
