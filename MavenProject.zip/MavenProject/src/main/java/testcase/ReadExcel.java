package testcase;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ReadExcel {
	@Test
	public static String[][] getData(String excelFileName) throws IOException {
		System.out.println(excelFileName);
		//open the file
		XSSFWorkbook book = new XSSFWorkbook("./testData/"+excelFileName+".xlsx");
		
		//select the sheet
		XSSFSheet sheet = book.getSheetAt(0);
		
		//find row count
		int rowSize = sheet.getLastRowNum();
		System.out.println("rowSize : "+rowSize);
		
		//find column size
		XSSFRow header = sheet.getRow(0);
		short columnSize = header.getLastCellNum();
		System.out.println("columnSize : "+columnSize);
		
		String[][] data = new String[rowSize][columnSize];
		//iterate to get each value from the table
		for(int i=1;i<=rowSize;i++){
			XSSFRow row = sheet.getRow(i);
			for(int j=0; j<columnSize;j++){
				XSSFCell eachCell = row.getCell(j);
				String value = eachCell.getStringCellValue();
				data[i-1][j] = value;
				System.out.println(value);
			}
		}
		//close book
		book.close();
		return data;
		
	}

}
