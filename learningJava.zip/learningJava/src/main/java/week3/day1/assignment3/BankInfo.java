package week3.day1.assignment3;

public class BankInfo {
	
	public void saving() {
		System.out.println("saving account");
	}
	
	public void fixed() {
		System.out.println("fixed account");
	}

	public void deposit() {
		System.out.println("deposit account parent");
	}


}
