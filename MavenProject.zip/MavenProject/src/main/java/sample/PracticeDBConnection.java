package sample;

import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class PracticeDBConnection {

	public static <Webdriver> void main(String[] args) throws ClassNotFoundException, SQLException, MalformedURLException {
		
	    String jdbc_driver = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/employee";
        String username = "localhost";
        String password = "welcome";
        String id;
        ChromeOptions idd = null;
        Class.forName(jdbc_driver);
        Connection connection = DriverManager.getConnection(url,username,password);
        Statement statement = connection.createStatement();
        String sql = "select * from employee.emp_details";
        ResultSet exeQuery = statement.executeQuery(sql);
        
        WebDriver driver = new RemoteWebDriver(new URL("http://192.168.0.123:4444/wd/hub"),idd);
        
        while(exeQuery.next()){
            id = exeQuery.getString(1);
            System.out.println(id);
        }
		
		
	}
}
