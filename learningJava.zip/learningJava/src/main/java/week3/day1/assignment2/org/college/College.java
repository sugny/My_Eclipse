package week3.day1.assignment2.org.college;

public class College {
	
	public void collegeName() {
		System.out.println("College Name ssec");
	}
	
	public void collegeCode() {
		System.out.println("college Code 419");
	}
	
	public void collegeRank() {
		System.out.println("College Rank 27");
	}
	

}
