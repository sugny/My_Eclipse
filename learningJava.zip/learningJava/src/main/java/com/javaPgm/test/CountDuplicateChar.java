package com.javaPgm.test;


public class CountDuplicateChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "welcome hii";
		str = str.replaceAll("\\s+", "");
		int l = str.length();
		for (int i = 0; i <=l-1; i++) {
			for (int j = i+1; j<=l-1; j++) {
				if(str.charAt(i)==str.charAt(j)) {
					System.out.println(str.charAt(j));
					break;
				}
			}
		}

	}

}
