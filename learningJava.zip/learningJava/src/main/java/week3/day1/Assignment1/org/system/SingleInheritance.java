package week3.day1.Assignment1.org.system;

public class SingleInheritance {

	public static void main(String[] args) {
		
		Desktop d = new Desktop();
		d.desktopSize();
		d.computerModel();	

	}

}
