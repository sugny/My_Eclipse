package com.javaPgm.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class CountWordsInString {

	public static void main(String[] args) {

		List<Integer> list = new ArrayList<>();
		list.add(100);
		list.add(200);
		list.add(300);
		list.add(400);
		list.add(500);
		list.add(600);
		int size = list.size();
		System.out.println(list);
		for(int i : list) {
			System.out.println(i);
		}
		System.out.println("----------------");
		Iterator itr = list.listIterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("----------------");
		for(int i=0;i<size;i++) {
			System.out.println(list.get(i));
		}
		
	}
}
