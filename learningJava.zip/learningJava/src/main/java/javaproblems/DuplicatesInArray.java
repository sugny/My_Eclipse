package javaproblems;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

public class DuplicatesInArray {

	public static void main(String[] args) {

		DuplicatesInArray da = new DuplicatesInArray();
		da.removeDulicates();
		da.learnList();
	}

	public void removeDulicates() {

		int[] arr = { 10, 70, 30, 90, 20, 20, 30, 40, 10, 10 };
		Arrays.sort(arr);
		int length = arr.length;
		int j = 0;
		for (int i = 0; i < length - 1; i++) {
			if (arr[i] != arr[i + 1]) {
				arr[j] = arr[i];
				j++;
			}
		}
		arr[j] = arr[length - 1];
		for (int i = 0; i <= j; i++) {
			System.out.println(arr[i]);
		}
	}
	
	public void learnList() {
		
		int[] input = {1,1,2,3,3,5,5,6,6,7};
		List<Integer> list = new ArrayList<Integer>();
		for (int number : input) {
			list.add(number);			
		}
		System.out.println(list);
		HashSet<Integer> toSet = new HashSet<Integer>();
		toSet.addAll(list);
		System.out.println(toSet);
	}
}
