package com.rsa.java;

public class MultiDimensionalArray {

	public static void main(String[] args) {

		// 1 5 6
		// 5 8 7
		// 7 3 9

		int arr[][] = { { 12, 25, 6 }, { 1, 513, 63 }, { 21, 57, 6512 } };
		int l = arr.length;
		int max = 0;

		// System.out.println(l);
		for (int i = 0; i < l; i++) {
			for (int j = 0; j < l; j++) {
				if (max < arr[i][j]) {
					max = arr[i][j];
				}
			}

		}
		int min = max;
		for (int i = 0; i < l; i++) {
			for (int j = 0; j < l; j++) {
				if (min > arr[i][j]) {
					min = arr[i][j];
				}
			}
		}
		System.out.println(max);
		System.out.println(min);

	}
}
