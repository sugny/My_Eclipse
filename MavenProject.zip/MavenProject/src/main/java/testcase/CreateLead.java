package testcase;


import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class CreateLead extends ProjectSpecificMethods {
		
		@BeforeTest
		public void setData(){
			excelFileName = "tc001";
		}
	
		@Test(dataProvider= "testData")
		public void createLead(String username,String password,String createLeadForm_companyName,String createLeadForm_firstName,String createLeadForm_lastName)  {
			driver.findElement(By.id("username")).sendKeys(username);
			driver.findElement(By.id("password")).sendKeys(password);
			driver.findElement(By.className("decorativeSubmit")).click();
			driver.findElement(By.linkText("CRM/SFA")).click();
			driver.findElement(By.linkText("Leads")).click();
			driver.findElement(By.linkText("Create Lead")).click();
			driver.findElement(By.id("createLeadForm_companyName")).sendKeys(createLeadForm_companyName);
			driver.findElement(By.id("createLeadForm_firstName")).sendKeys(createLeadForm_firstName);
			driver.findElement(By.id("createLeadForm_lastName")).sendKeys(createLeadForm_lastName);
			driver.findElement(By.name("submitButton")).click();
		}
		
		/*@DataProvider(name = "testData")
		public String[][] sendData(){
			
			String[][] data = new String[2][5];
			data[0][0] = "DemoSalesManager";
			data[0][1] = "crmsfa";
			data[0][2] = "TestLeaf";
			data[0][3] = "Hari";
			data[0][4] = "R";
			
			data[1][0] = "DemoSalesManager";
			data[1][1] = "crmsfa";
			data[1][2] = "TestLeaf";
			data[1][3] = "Aravind";
			data[1][4] = "R";
			
			return data;	
		*/
		
	}		






