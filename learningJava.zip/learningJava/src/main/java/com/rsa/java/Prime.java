package com.rsa.java;

import java.util.Scanner;

public class Prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count = 0;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number : ");
		int input = sc.nextInt();
		for (int i = 2; i < input; i++) {
			
		if (input % i == 0)
				count++;
		}
		if (count > 1) {
			//System.out.println(count);
			System.out.println("Not Prime");
		}
		else {
			//System.out.println(count);
			System.out.println("is Prime");
		}
		sc.close();
	}
}
