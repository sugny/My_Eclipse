package javaproblems;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int input = sc.nextInt();
		sc.close();
		Factorial f = new Factorial();
		f.isFactorial(input);
	}
	
	public void isFactorial(int input) {
		
		int result=1;
		for(int i=1;i<=input;i++) {
			result = result * (i);
		}
		System.out.println(result);
	}
}
