package week7.day2.assignment;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class IOpropertyFile {
	
	Properties prop = new Properties();
	public String readPropertyFile(String key) throws IOException {
		
		FileInputStream fis = new FileInputStream("./src/main/resources/configuration.properties");		
		prop.load(fis);
		return prop.getProperty(key);
		
	}
	
	public void writePropertyFile(String value) throws IOException {
		
		FileOutputStream fos = new FileOutputStream("./src/main/resources/configuration.properties");
		prop.setProperty("title", value);
		prop.store(fos, "title of the page");
		
	}

}
