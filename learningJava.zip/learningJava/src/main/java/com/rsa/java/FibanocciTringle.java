package com.rsa.java;

public class FibanocciTringle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 12358
		
		
		int sum =0;
		int input = 8;
		for (int j = 1; j <=input; j++) {
			int a = 0;
			int b = 1;
			for (int i = 1; i <=j; i++) {
				sum = a + b;
				System.out.print(sum+ " ");
				a = b;
				b = sum;
			}
			System.out.println(" ");
			
		}
	}

}
